<?php

if (\PHP_VERSION_ID >= 80100) {
    return;
}

/** @internal */
final class ReflectionEnum
{
    public function __construct($enum)
    {
    }
}

