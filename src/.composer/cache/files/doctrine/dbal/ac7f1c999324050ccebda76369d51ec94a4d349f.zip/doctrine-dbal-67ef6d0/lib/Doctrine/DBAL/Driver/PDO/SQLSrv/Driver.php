<?php

namespace Doctrine\DBAL\Driver\PDO\SQLSrv;

use Doctrine\DBAL\Driver\PDOSqlsrv;

final class Driver extends PDOSqlsrv\Driver
{
}
