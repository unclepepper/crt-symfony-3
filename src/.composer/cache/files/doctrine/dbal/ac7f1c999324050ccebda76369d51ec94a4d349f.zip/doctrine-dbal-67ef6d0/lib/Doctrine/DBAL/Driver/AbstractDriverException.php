<?php

namespace Doctrine\DBAL\Driver;

/**
 * @deprecated
 *
 * @psalm-immutable
 */
class AbstractDriverException extends AbstractException
{
}
