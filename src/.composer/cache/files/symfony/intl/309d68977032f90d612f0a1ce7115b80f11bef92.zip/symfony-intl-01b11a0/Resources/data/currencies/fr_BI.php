<?php

return [
    'Names' => [
        'BIF' => [
            0 => 'FBu',
            1 => 'franc burundais',
        ],
    ],
];
