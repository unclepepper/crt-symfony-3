<?php

return [
    'Names' => [
        'BOB' => [
            0 => 'Bs',
            1 => 'boliviano',
        ],
    ],
];
