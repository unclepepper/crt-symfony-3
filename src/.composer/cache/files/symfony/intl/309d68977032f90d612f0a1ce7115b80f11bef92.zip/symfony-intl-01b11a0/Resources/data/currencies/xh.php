<?php

return [
    'Names' => [
        'ZAR' => [
            0 => 'R',
            1 => 'iRandi yaseMzanzi Afrika',
        ],
    ],
];
