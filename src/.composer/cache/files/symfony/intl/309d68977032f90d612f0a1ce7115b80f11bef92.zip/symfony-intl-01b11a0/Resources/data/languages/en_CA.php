<?php

return [
    'Names' => [
        'bn' => 'Bengali',
        'mfe' => 'Mauritian',
        'mus' => 'Creek',
        'sah' => 'Yakut',
        'tvl' => 'Tuvaluan',
    ],
    'LocalizedNames' => [
        'nds_NL' => 'West Low German',
        'ro_MD' => 'Moldovan',
    ],
];
