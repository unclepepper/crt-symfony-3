<?php

return [
    'Names' => [
        'LUF' => [
            0 => 'F',
            1 => 'Franco luxemburguês',
        ],
    ],
];
