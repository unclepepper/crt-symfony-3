<?php

return [
    'Names' => [
        'CLP' => [
            0 => '$',
            1 => 'Peso chileno',
        ],
        'USD' => [
            0 => 'US$',
            1 => 'dólar estadounidense',
        ],
    ],
];
