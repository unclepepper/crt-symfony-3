<?php

return [
    'Names' => [
        'ANG' => [
            0 => 'ANG',
            1 => 'florín de las Antillas Neerlandesas',
        ],
        'BMD' => [
            0 => 'BMD',
            1 => 'dólar de Bermudas',
        ],
        'EUR' => [
            0 => 'EUR',
            1 => 'euro',
        ],
        'HTG' => [
            0 => 'HTG',
            1 => 'gourde haitiano',
        ],
        'KZT' => [
            0 => 'KZT',
            1 => 'tenge kazajo',
        ],
        'MWK' => [
            0 => 'MWK',
            1 => 'kwacha malauí',
        ],
        'NIO' => [
            0 => 'NIO',
            1 => 'córdoba nicaragüense',
        ],
        'THB' => [
            0 => 'THB',
            1 => 'baht tailandes',
        ],
        'USD' => [
            0 => 'USD',
            1 => 'dólar estadounidense',
        ],
        'UZS' => [
            0 => 'UZS',
            1 => 'som uzbeko',
        ],
        'VND' => [
            0 => 'VND',
            1 => 'dong',
        ],
    ],
];
