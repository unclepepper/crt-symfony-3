<?php

return [
    'Names' => [
    ],
    'LocalizedNames' => [
        'ar_001' => 'Larabci Asali Na Zamani',
        'de_AT' => 'Jamusanci Ostiriya',
        'de_CH' => 'Jamusanci Suwizalan',
        'en_AU' => 'Turanci Ostareliya',
        'en_CA' => 'Turanci Kanada',
        'en_GB' => 'Turanci Biritaniya',
        'en_US' => 'Turanci Amirka',
        'es_419' => 'Sifaniyancin Latin Amirka',
        'es_ES' => 'Sifaniyanci Turai',
        'es_MX' => 'Sifaniyanci Mesiko',
        'fa_AF' => 'Vote Farisanci na Afaganistan',
        'fr_CA' => 'Farasanci Kanada',
        'fr_CH' => 'Farasanci Suwizalan',
        'pt_BR' => 'Harshen Potugis na Birazil',
        'pt_PT' => 'Potugis Ƙasashen Turai',
        'zh_Hans' => 'Sauƙaƙaƙƙen Sinanci',
        'zh_Hant' => 'Sinanci na gargajiya',
    ],
];
