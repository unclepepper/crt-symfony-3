<?php

return [
    'Names' => [
        'ZMW' => [
            0 => 'K',
            1 => 'Zambian Kwacha',
        ],
    ],
];
