Symfony Polyfill / Uuid
========================

This component provides `uuid_*` functions to users who run PHP versions without the uuid extension.

More information can be found in the
[main Polyfill README](https://github.com/symfony/polyfill/blob/master/README.md).

License
=======

This library is released under the [MIT license](LICENSE).
